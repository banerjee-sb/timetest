# flask-cloud-storage
The personal documentation of me learning to upload file to Google Cloud Storage using Flask app
