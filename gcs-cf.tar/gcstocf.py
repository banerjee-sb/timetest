from google.cloud import storage
import pandas as pd
import openpyxl
import pandas_gbq

def list_blobs(request):

    bucket_name='project-gwc-374204-urlsigner'
    storage_client = storage.Client()
    blobs = storage_client.list_blobs(bucket_name)
    df_final = pd.DataFrame(columns=['Name', 'Date', 'Start', 'End', 'Project', 'Task', 'Highlights'])

    for blob in blobs:
        blob_name = blob.name
        bucket = storage_client.bucket(bucket_name)
        file = bucket.blob(blob_name)
        data_bytes = file.download_as_bytes()
        df = pd.read_excel(data_bytes)
        df["Name"].fillna(df['Name'][0], inplace = True)
        df["Date"].fillna(df['Date'][0], inplace = True)

        df_final=df_final.append(df)
    df_final['Start']=df_final['Start'].astype(str)
    df_final['End']=df_final['End'].astype(str)
    df_final=df_final.drop(['Highlights '],axis=1)
    print(df_final)


    df_final_bq=df_final.to_gbq('project-gwc-374204.signed_url_ds.signed_url_tbl', 
                 chunksize=10000, 
                 if_exists='append'
                 )
    return df_final
